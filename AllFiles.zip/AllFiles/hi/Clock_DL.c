/*
 * Clock_DL.c
 *
 */


/* Standard Includes */
#include <stdint.h>
#include <stdbool.h>
/* Project Includes */
#include "Clock.h"
#include "msp.h"
#include "GPIO.h"
#include "PCM.h"
#include "FLASH.h"
#include "CS.h"

/*
 * HFXT_Init TODO:
 * Initialize HFXT oscillator in the power state allowing for maximum operating frequency of 48 MHz
 * 1. Set appropriate PJ pins to HFXT in/out mode
 * 2. Enable higher power state to allow 48 MHZ operation
 * 3. Set wait state for flash controllers (must be called when changing clock frequency ranges)
 * 4. Set start HFXT
 */
void HFXT_Init(void){
    //1
        GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_PJ, GPIO_PIN3 | GPIO_PIN2, GPIO_PRIMARY_MODULE_FUNCTION);
        GPIO_setAsOutputPin(GPIO_PORT_P1, GPIO_PIN0);
        //2
        PCM_setCoreVoltageLevel(PCM_VCORE1);
        //3
        FlashCtl_setWaitState(FLASH_BANK0, 2);
        FlashCtl_setWaitState(FLASH_BANK1, 2);
        //4 (change?)
        CS_startHFXT(false);

}

/*
 * Clock_Init TODO:
 * 1. Set frequency for HFXT crystal to 48MHz
 * 2. Call HFXT_Init
 * 3. Init MCLK to 48MHz
 * 4. Init SMCLK to 12MHz (1/4 of MCLK)
 */
void Clock_Init(){
    CS_setExternalClockSourceFrequency(32000, 48000000);
    HFXT_Init();
    CS_initClockSignal(CS_MCLK, CS_HFXTCLK_SELECT, CS_CLOCK_DIVIDER_1);
    CS_initClockSignal(CS_SMCLK, CS_HFXTCLK_SELECT, CS_CLOCK_DIVIDER_4); //divider 4 bc we dont need to divide anything
}








